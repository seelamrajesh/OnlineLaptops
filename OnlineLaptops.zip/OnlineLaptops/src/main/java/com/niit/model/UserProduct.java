package com.niit.model;

import java.io.Serializable;

public class UserProduct implements Serializable {
	
	private String proId;
	private String proName;
	private String proBrand;
	private int proPrice;
	private int proStock;
	
	
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public String getProBrand() {
		return proBrand;
	}
	public void setProBrand(String proBrand) {
		this.proBrand = proBrand;
	}
	public int getProPrice() {
		return proPrice;
	}
	public void setProPrice(int proPrice) {
		this.proPrice = proPrice;
	}
	public int getProStock() {
		return proStock;
	}
	public void setProStock(int proStock) {
		this.proStock = proStock;
	}
	
	public UserProduct(String proId,String proName,String proBrand,int proPrice,int proStock)
	{
		this.setProId(proId);
		this.proName=proName;
		this.proBrand=proBrand;
		this.proPrice=proPrice;
		this.proStock=proStock;
		
	}
	public String getProId() {
		return proId;
	}
	public void setProId(String proId) {
		this.proId = proId;
	}
	
	

}
