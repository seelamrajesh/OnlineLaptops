package com.niit.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.model.UserProduct;

@Repository
public class UserProductDao {
	public List addUserProduct()
	{
	ArrayList<UserProduct>	al=new ArrayList();
	return al;
	}

}
